﻿using System;
using System.Collections.Generic;
using System.Linq;
using Exiled.API.Enums;
using Exiled.API.Features;

namespace RGM.Modes;

public abstract class Ability
{
    public abstract void OnEnabled();

    public abstract void OnDisabled();

    public AbilityData Data { get; set; }
    public Player Owner { get; set; }
}

public abstract class EffectAbility : Ability
{
    public abstract Dictionary<EffectType, byte> EffectTypes { get; }

    public override void OnEnabled()
    {
        foreach (var effect in EffectTypes)
        {
            Owner.AddEffect(effect.Key, effect.Value);
        }
    }

    public override void OnDisabled()
    {
        foreach (var effect in EffectTypes)
        {
            Owner.RemoveEffect(effect.Key, effect.Value);
        }
    }
}

public abstract class ItemAbility : Ability
{
    public abstract ItemType ItemType { get; }
    public abstract int Amount { get; }

    public override void OnEnabled()
    {
        Owner.AddItem(ItemType, Amount);
    }

    public override void OnDisabled()
    {
        for (int i = 0; i < Amount; i++)
        {
            var item = Owner.Items.FirstOrDefault(x => x.Type == ItemType);

            if (item == null)
                break;

            Owner.RemoveItem(item);
        }
    }
}

public class AbilityData
{
    public Type Type { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public AbilityCategory Category { get; set; }
    public AbilityType AbilityType { get; set; }
    public List<AbilityType> Requires { get; set; }
    public bool Keep { get; set; }

    public string GetFormattedName()
    {
        return $"<color={Category.GetColor()}>[{Category.GetTranslation()}]</color> {Name}";
    }
}

[AttributeUsage(AttributeTargets.Class)]
public class AbilityAttribute(string name, string description, AbilityCategory category, AbilityType type, bool keep = false) : Attribute
{
    public string Name { get; } = name;
    public string Description { get; } = description;
    public AbilityCategory Category { get; } = category;
    public AbilityType Type { get; set; } = type;
    public bool Keep { get; set; } = false;
}

[AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
public class RequiresAbilityAttribute(params AbilityType[] abilities) : Attribute
{
    public AbilityType[] Abilities { get; } = abilities;
}

public enum AbilityCategory
{
    None,
    Common,
    Rare,
    Epic,
    Legend,
    Mythic,
    ClassD,
    Scientist,
    Guard,
    Ntf,
    Chaos,
    Snake,
    Scp173,
    Scp049,
    Scp0492,
    Scp096,
    Scp106,
    Scp939,
    Scp3114,
    Scp079,
    Synergy,
}

public static class AbilityCategoryExtensions
{
    public static string GetTranslation(this AbilityCategory category)
    {
        return category switch
        {
            AbilityCategory.Common => "일반",
            AbilityCategory.Rare => "희귀",
            AbilityCategory.Epic => "영웅",
            AbilityCategory.Legend => "전설",
            AbilityCategory.Mythic => "신화",
            AbilityCategory.ClassD => "전용",
            AbilityCategory.Scientist => "전용",
            AbilityCategory.Guard => "전용",
            AbilityCategory.Ntf => "전용",
            AbilityCategory.Chaos => "전용",
            AbilityCategory.Snake => "전용",
            AbilityCategory.Scp173 => "전용",
            AbilityCategory.Scp049 => "전용",
            AbilityCategory.Scp0492 => "전용",
            AbilityCategory.Scp096 => "전용",
            AbilityCategory.Scp106 => "전용",
            AbilityCategory.Scp939 => "전용",
            AbilityCategory.Scp3114 => "전용",
            AbilityCategory.Scp079 => "전용",
            AbilityCategory.Synergy => "시너지",
            _ => "알 수 없음"
        };
    }
    
    public static string GetColor(this AbilityCategory category)
    {
        return category switch
        {
            AbilityCategory.Common => "#A4A4A4",
            AbilityCategory.Rare => "#2ECCFA",
            AbilityCategory.Epic => "#FF00FF",
            AbilityCategory.Legend => "#ffd700",
            AbilityCategory.Mythic => "#DF0101",
            AbilityCategory.ClassD => "#F7819F",
            AbilityCategory.Scientist => "#F7819F",
            AbilityCategory.Guard => "#F7819F",
            AbilityCategory.Ntf => "#F7819F",
            AbilityCategory.Chaos => "#F7819F",
            AbilityCategory.Snake => "#F7819F",
            AbilityCategory.Scp173 => "#F7819F",
            AbilityCategory.Scp049 => "#F7819F",
            AbilityCategory.Scp0492 => "#F7819F",
            AbilityCategory.Scp096 => "#F7819F",
            AbilityCategory.Scp106 => "#F7819F",
            AbilityCategory.Scp939 => "#F7819F",
            AbilityCategory.Scp3114 => "#F7819F",
            AbilityCategory.Scp079 => "#F7819F",
            AbilityCategory.Synergy => "#DEEFED",
            _ => "white"
        };
    }
}

public enum AbilityType
{
    NONE,

    // 일반 //
    NORMAL_WORKOUT, // [일반] 운동
    NORMAL_SWIFT, // [일반] 경공
    NORMAL_EVOLUTION, // [일반] 진화
    NORMAL_TRAINING, // [일반] 단련
    NORMAL_LUCKY, // [일반] 행운
    NORMAL_STAMINAREPLENISHMENT, // [일반] 체력 보충
    NORMAL_RANDOMBOX, // [일반] 랜덤박스
    NORMAL_FINDLOCATION, // [일반] 위치 추적
    NORMAL_INSURANCE, // [일반] 보험
    NORMAL_KICK, // [일반] 회축
    NORMAL_SUPPLY, // [일반] 보급
    NORMAL_PURIFICATION, // [일반] 정화
    NORMAL_TORCH, // [일반] 횃불
    NORMAL_SNEAK, // [일반] 잠행
    NORMAL_ESCAPE, // [일반] 위기 탈출
    NORMAL_FRIENDSHIP, // [일반] 우애
    NORMAL_RAINBOW, // [일반] 무지개
    NORMAL_BODYBACK, // [일반] 바디백
    NORMAL_DOPAMINE, // [일반] 도파민

    // 희귀 //
    RARE_PHYSICALSTRENGTHENING, // [희귀] 육체 강화
    RARE_STEELSHELL, // [희귀] 강철 껍질
    RARE_TRANSPARENTCLOAK, // [희귀] 투명 망토
    RARE_VAMPIRE, // [희귀] 흡혈귀
    RARE_TELEPORTATION, // [희귀] 순간이동
    RARE_BOMBERMAN, // [희귀] 봄버맨
    RARE_GRAPPLINGHOOK, // [희귀] 갈고리
    RARE_STOPWATCH, // [희귀] 회중시계
    RARE_STEROID, // [희귀] 스테로이드
    RARE_MARTYRDOM, // [희귀] 순교
    RARE_HYPASS, // [희귀] 하이패스
    RARE_TRIPLEAXEL, // [희귀] 트리플악셀
    RARE_ALCHEMY, // [희귀] 연금
    RARE_ADHESIVEPLASTER, // [희귀] 반창고
    RARE_WEAPONEXPERT, // [희귀] 무기 전문가
    RARE_PANACEA, // [희귀] 만병통치약
    RARE_SALAMANDRA, // [희귀] 불의 정령, 살라만드라
    RARE_UNDINE, // [희귀] 물의 정령, 운디네
    RARE_GNOME, // [희귀] 흙의 정령, 노움
    RARE_SYLPH, // [희귀] 바람의 정령, 실프
    RARE_CONTRACT, // [희귀] 계약
    RARE_TRANSITION, // [희귀] 하급 변이

    // 영웅 //
    EPIC_TERRORISTREMAINS, // [영웅] 테러리스트의 유품
    EPIC_GAMBLER, // [영웅] 도박꾼
    EPIC_RANDOMCHEST, // [영웅] 랜덤상자
    EPIC_REPAIRMAN, // [영웅] 수리 기사
    EPIC_SUPERSTAR, // [영웅] 슈퍼 스타
    EPIC_LUCKYVIKEY, // [영웅] 럭키비키
    EPIC_EXTREMEPOISON, // [영웅] 극독
    EPIC_SURVIVOR, // [영웅] 구사일생
    EPIC_REGENERATION, // [영웅] 초재생
    EPIC_GHOSTRULE, // [영웅] 고스트룰
    EPIC_DIVER, // [영웅] 잠수부
    EPIC_BLINK, // [영웅] 점멸
    EPIC_TRANSITION, // [영웅] 변이

    // 전설 //
    LEGEND_SPEEDWAGON, // [전설] 스피드왜건
    LEGEND_SNAKEHANDRADIO, // [전설] 뱀의 손 무전기
    LEGEND_RANDOMPACKAGE, // [전설] 랜덤택배
    LEGEND_MAGICIAN, // [전설] 마술사
    LEGEND_FLASHLIGHT, // [전설] 플래시라이트
    LEGEND_KILLSTREAK, // [전설] 킬스트릭
    LEGEND_FLAMETHROWER, // [전설] 화염 방사기
    LEGEND_PSYCHICS, // [전설] 영매
    LEGEND_SCREAM, // [전설] 괴성
    LEGEND_TRANSITION, // [전설] 상급 변이

    // 신화 //
    MYTHIC_ROCKETLAUNCHER, // [신화] 로켓 런처
    MYTHIC_SPIRIT, // [신화] 스피릿
    MYTHIC_EYEMAN, // [신화] 눈빛맨
    MYTHIC_DIMENSIONTHIEF, // [신화] 차원 강탈자
    MYTHIC_JOKER, // [신화] 조커
    MYTHIC_WARGOD, // [신화] 광전사

    // 전용 //
    // D계급
    CLASSD_LARCENY, // [전용] 절도죄
    CLASSD_TRESPASSING, // [전용] 주거침입죄
    CLASSD_SEEDSOFREBELLION, // [전용] 반란의 씨앗

    // 과학자
    SCIENTIST_05, // [전용] 05 평의회
    SCIENTIST_ENGINEERINGMAJOR, // [전용] 공학 전공
    SCIENTIST_SEEDSOFSPECIALFORCES, // [전용] 특무부대의 씨앗

    // 시설 경비
    FACILITYGUARD_MANAGERIALOBLIGATIONPERSON, // [전용] 관리 의무자
    FACILITYGUARD_HEALTHCENTERSTAFF, // [전용] 보건소 직원
    FACILITYGUARD_INDUSTRIALACCIDENTINSURANCE, // [전용] 산업재해보험

    // 구미호
    MTF_QUARANTINEOBLIGATION, // [전용] 격리 의무자
    MTF_MEDICALOFFICER, // [전용] 의무병
    MTF_COLLECTIVEINTELLIGENCE, // [전용] 집단 지성
    MTF_RADAR, // [전용] 레이더

    // 혼돈의 반란
    CHI_CHAOSOFCHAOS, // [전용] 혼돈의 카오스
    CHI_TOUCHOFCHAOS, // [전용] 혼돈의 손길
    CHI_BAGOFCHAOS, // [전용] 혼돈의 가방

    // 뱀의 손
    TUTORIAL_TONGUE, // [전용] 세치 혀
    TUTORIAL_THIRDFORCE, // [전용] 제3세력
    TUTORIAL_RESEARCHER, // [전용] SCP 연구자

    // SCP-173
    SCP173_FEAR, // [전용] 공포
    SCP173_ABERRATION, // [전용] 괴이
    SCP173_MIRAGE, // [전용] 신기루

    // SCP-049
    SCP049_LION, // [전용] 사자
    SCP049_COMPETENTDOCTOR, // [전용] 유능한 의사
    SCP049_PROFICIENCY, // [전용] 능수능란

    // SCP-0492
    SCP0492_HUNGER, // [전용] 허기
    SCP0492_MESSHALL, // [전용] 급식
    SCP0492_CONFUSION, // [전용] 당혹감

    // SCP-096
    SCP096_RAGE, // [전용] 격노
    SCP096_STARTEARING, // [전용] 별자리 찢기
    SCP096_CLEANSING, // [전용] 천리안
    SCP096_ENEMY, // [전용] 원수

    // SCP-106
    SCP106_REJUVENATION, // [전용] 회춘
    SCP106_STICKYSWAMP, // [전용] 끈적한 늪
    SCP106_HUNTINGPREY, // [전용] 사냥감 모색

    // SCP-939
    SCP939_IMPERSONATOR, // [전용] 흉내쟁이
    SCP939_HUGME, // [전용] 안아줘요
    SCP939_AGILEHUNTINGTOOL, // [전용] 민첩한 사냥 도구

    // SCP-3114
    SCP3114_SKILLEDASSASSIN, // [전용] 숙련된 암살자
    SCP3114_HALFBLOCK, // [전용] 반블럭
    SCP3114_DORAEMONPOCKET, // [전용] 도라에몽 주머니

    // SCP-079
    SCP079_PINGREMOTE, // [전용] 핑 리모컨
    SCP079_PORTABLECHARGER, // [전용] 간이 충전기
    SCP079_OVERCURRENT, // [전용] 과전류
    SCP079_RANDOMFUNCTION, // [전용] 랜덤 함수
    SCP079_ANCIENTBEINGOVERWHELM, // [전용] 고대의 존재 압도

    // 시너지 //
    SYNERGY_SURVIVALEXPERT, // [시너지] 생존 전문가
    SYNERGY_GLORY, // [시너지] 광휘
    SYNERGY_RANDOMCOLLECTION, // [시너지] 랜덤 컬렉션
    SYNERGY_FOURMAJOREXERCISES, // [시너지] 4대 운동
    SYNERGY_DUPLICATEFATE, // [시너지] 중복 기연
    SYNERGY_DRUID, // [시너지] 드루이드
}

public static class AbilityTypeExtensions
{
    public static string GetTranslation(this AbilityType type)
    {
        var aBattle = ABattle.Instance;

        if (!aBattle.Abilities.TryGetValue(type, out var ability))
            return "알 수 없음";

        return ability.GetFormattedName();
    }
}